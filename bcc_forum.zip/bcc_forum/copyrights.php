

<?php include('header.php'); ?>

  <body id="home">
  <br />
  <?php  include('navbar_index.php');  ?>
   
  <div class="container-fluid">
  
 
  
  
<div class="row">
   
  <div class="col-md-12">

		<!-- Modal -->
		<div   id="copyrights" tabindex="-1" >
		<div class="modal-dialog">
			<div class="modal-content">
			<div class="modal-header">
				<a href="index.php" type="button" class="close"  >&times;</a>
				<h4 class="modal-title" id="myModalLabel">Copyright Policy</h4>
			</div>
			<div class="modal-body">
			<p>
Any and all of the content presented on the Online Forum for IT Professional
 and Students website is, unless explicitly stated otherwise, subject 
 to a copyright held by Online Forum for IT Professional and Students. It
 is permissible to link to content from this site as long as the original 
 source is clearly stated, but the wholesale reproduction or partial modification 
 of content is not permitted. Exceptions are granted only if you receive prior written
  consent from Online Forum for IT Professional and Students or the one who post.</p>
			</div>
			<div class="modal-footer">
				<a href="index.php" type="button" class="btn btn-default"  ><i class="fa fa-times"></i> Close</a>
				
			</div>
			</div>
			
		</div>
		</div>
        
  </div>
 
</div>
 
  </div>
  
 
  </body>
 

