	<div class="container-fluid">
	<div class="row">
	<div class="col-md-12">
	<nav class="navbar navbar-default alert-success" role="navigation">
	<div class="container-fluid">
		<!-- Brand and toggle get grouped for better mobile display -->
		<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	
		</div>
	
		<!-- Collect the nav links, forms, and other content for toggling -->
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <br />
        <table border="0">
        <tr>
        <td width="840">
        <font size="5">
   <a href="admin/index.php"><img title="Administrator login" src="images/logo_forum.png" width="50" height="50" alt="..." class="img-square"/></a> Online Forum for I.T. Professionals and Students
         </font>
        </td>
        <td  >
        </td>
        <td>
        <?php include('login_form.php'); ?>
        </td>
        </tr>
        </table>
			<br />
             	
		</div><!-- /.navbar-collapse -->
	</div><!-- /.container-fluid -->
	</nav>
	</div>
	</div>
	</div>