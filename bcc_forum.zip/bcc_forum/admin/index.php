<?php include('header.php'); ?>
  <body id="home">
  <br />
  <?php  include('navbar_index.php');  ?>
   
  <div class="container-fluid">
  
 
  
  
<div class="row">
  <div class="col-md-12"></div>
  <div class="col-md-12">
			<div class="alert alert-danger">
<br />
        <center>
        <table border="0"> 
        <tr>
        <td >
        <img src="../images/forum.png" width="1200" height="420" alt="..." class="img-square thumbnail">
        </td>
       
        </tr>
        </table>
        </center>
        </div>
  </div>
  <div class="col-md-12"></div>
</div>
 
  </div>
   
  </body>
</html>