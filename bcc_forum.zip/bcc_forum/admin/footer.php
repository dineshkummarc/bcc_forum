 
  <div class="row">
   <div class="col-md-12">
	<footer>
	 
     
     <ul class="nav navbar-nav navbar-right">
      	<li><a href="home.php"><i class="fa fa-group"></i> Members</a></li>
			<li><a href="admin_user.php"><i class="fa fa-user"></i> Admin Users</a></li>
        	<li><a href="admin_forum/home.php"><i class="fa fa-comment"></i> Forum Page</a></li>
            <li><a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a></li>

         
       
      </ul>
      
	</footer>
	</div>
	</div>
 <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="../js/bootstrap.min.js"></script>

 
