<?php
$conn = new PDO('mysql:host=localhost;dbname=bcc_forum', 'root', '');
?>
