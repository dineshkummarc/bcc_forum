<!DOCTYPE html>
<html lang="en">
  <head>
  
  
  <link rel="icon" href="../../images/logo_forum.png" type="image" />
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>Forum-Admin</title>
    <!-- Bootstrap -->
    <link href="../../css/bootstrap.min.css" rel="stylesheet"/>
    <link href="../../css/my_style.css" rel="stylesheet"/>
    <link href="../../css/font-awesome.min.css" rel="stylesheet"/>
<!-- data table -->
  <script src="../../js/jquery.min.js"></script>
		
				<link href="../jGrowl/jquery.jgrowl.css" rel="stylesheet" media="screen">
		<script src="../../jGrowl/jquery.jgrowl.js"></script>
		<script src="../../jGrowl/jquery.jgrowl.js"></script>
        
        
  </head>
  <?php  date_default_timezone_set('Asia/Manila'); include('dbcon.php') ?>