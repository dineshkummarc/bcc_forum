<?php include('header.php'); ?>

  <body id="home">
  <br />
  <?php  include('navbar_index.php');  ?>
   
  <div class="container-fluid">
  
 
  
  
<div class="row">
   
  <div class="col-md-12">

		<?php include('register_me.php'); ?>
        
  </div>
 
</div>
 
  </div>
  
 
  </body>
 