

<?php include('header.php'); ?>

  <body id="home">
  <br />
  <?php  include('navbar_index.php');  ?>
   
  <div class="container-fluid">
  
 
  
  
<div class="row">
   
  <div class="col-md-12">

	 	<!-- Modal -->
	<div   id="tc" tabindex="-1" >
		<div class="modal-dialog">
			<div class="modal-content">
			<div class="modal-header">
			<a href="index.php" type="button" class="close"  >&times;</a>
				<h4 class="modal-title" id="myModalLabel">Online Forum Terms and Conditions</h4>
			</div>
			<div class="modal-body">
			<p>
By using the message board(s) you agree to these terms and conditions.<br /><br />
All messages are the opinions of the author and are not the views or opinions of Online Forum for IT Professional and Students ("FIPAS").  Please note that some of the boards may be intended for use by young people; please have regard to this.<br /><br />
Notwithstanding any other provision of these Terms, nothing in these Terms shall operate to exclude FIPAS's liability for personal injury and/or death caused by its negligence.<br /><br />
You agree that:
<ul>
<li>
	Use by you of the message boards is entirely at your own risk;</li>
<li>	You are responsible for the content of the messages you post and any consequences that flow from such posting(s);</li>
<li>	FIPAS will not be liable for any errors or omissions in any postings or for any loss or damages incurred as a result of the use of any information contained in the message boards;</li>
<li>	FIPAS makes no guarantee or gives warranty of any kind whatsoever (whether express or implied) in relation to your use of the message board(s) or any use by any third parties; and</li>
<li>	FIPAS shall not be liable for any loss or damage (whether direct, indirect, consequential, financial or otherwise) arising from the use of (or in connection with) the message board(s). 
</li>
</ul>
Subject to the third paragraph of these terms in relation to FIPAS your sole and exclusive remedy for using the message board(s) and/or any information contained on the same is to stop using the message board(s) and/or any information contained on it/them.<br /><br />
FIPAS does not guarantee that the use of the message board(s) by you will be uninterrupted, error free, free from any third party interference or that the message board(s) will be free from computer viruses or other malicious software.<br /><br />
It is your responsibility to implement sufficient procedures and virus checks (including anti-virus and other security checks) to satisfy your particular requirements for the accuracy of data input and output.<br /><br />
Any information disclosed on the message boards themselves will become public information.<br /><br />
For your own safety you should not disclose personal information such as your email address, home address or telephone number (or any information which would identify you indirectly) on any message board(s).<br /><br />
You further agree not to do any of the following:
<ul>
<li>	post any information that is unlawful, harmful, threatening, abusive, harassing, vulgar, profane, obscene, may cause personal distress, offensive, defamatory, false, libellous, hateful, racially, sexually or otherwise discriminatory or post any information that is otherwise (in the absolute discretion of FIPAS) objectionable;</li>
<li>	impersonate any person or entity, or misrepresent your association with a person or entity;</li>

 
<li>	promote or endorse any business or commercial goods, products or publications (including other websites except YouTube for videos);</li>
<li>	post any information that may be invasive of another's privacy or violate the rights of any other member, or of any third party in any way;</li>
<li>	post inflammatory messages;</li>
<li>	post any content that infringes any patent, trademark or copyright of any party unless you have the permission to do so;</li>
<li>	use the boards to encourage illegal and/or inappropriate behaviour, to form or recruit members for distinct groups whose aims are to cause disruption, or to encourage others to do so;</li>
<li>	use the boards to promote or provide instructional information about illegal activities or promote physical harm or injury against any group or individual;</li>
<li>	post any information that would be in breach of a court order from a court of competent jurisdiction;</li>
<li>	post any information that is confidential and/or commercially sensitive;</li>
<li>	post any URLs or web links (to avoid doubt, SCC takes no responsibility for the content of any external URL or web link if posted in contravention of these Terms);</li>
<li>	post the names of any individual (or identify any individual by any other means) in relation to (or in connection with) criminal accusations and/or any current criminal proceedings.</li>
<li>	Spoil, spam, impersonate or engage in activity or behaviour which SCC regard as objectionable and/or inappropriate.</li>
</ul>
If you are offended by a post or topic please use the <a href="#">onlineforumforitproffandstud@yahoo.com</a> email address to give an alert to the administrator. Please do not use this facility if you simply disagree with what has been posted; if this is the case post a reply stating your opposing opinion.  When doing so do not make any personal attacks. If you disagree with another member of the boards or with a situation, state your case without attacking or insulting others, and treat others with respect.<br /><br />
</p>
			</div>
			<div class="modal-footer">
				<a href="index.php" type="button" class="btn btn-default"  ><i class="fa fa-times"></i> Close</a>
				
			</div>
			</div>
			
		</div>
		</div>
        
  </div>
 
</div>
 
  </div>
  
 
  </body>
 
 