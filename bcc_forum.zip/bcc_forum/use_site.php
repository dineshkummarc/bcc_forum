


<?php include('header.php'); ?>

  <body id="home">
  <br />
  <?php  include('navbar_index.php');  ?>
   
  <div class="container-fluid">
  
 
  
  
<div class="row">
   
  <div class="col-md-12">

	<!-- Modal -->
	<div   id="use" tabindex="-1" >
		<div class="modal-dialog">
			<div class="modal-content">
			<div class="modal-header">
				<a href="index.php" type="button" class="close"  >&times;</a>
				<h4 class="modal-title" id="myModalLabel">Use of the Site</h4>
			</div>
			<div class="modal-body">
			<p>
The Online Forum for IT Professional and Students website hosts a forum and somehow a blog for IT interest, both of which are equipped with commenting facilities. While we invite you to share your opinions and questions in this way, they must not be used to distribute spam messages, post commercial advertisements, or spread links to malicious or dangerous websites. We do retain the right to moderate any comment or written content submitted to the Online Forum for IT Professional and Students website and to remove any content we deem to have violated our policies.
</p>
			</div>
			<div class="modal-footer">
				<a href="index.php" type="button" class="btn btn-default"  ><i class="fa fa-times"></i> Close</a>
				
			</div>
			</div>
			
		</div>
		</div>	 
        
  </div>
 
</div>
 
  </div>
  
 
  </body>
 
 
