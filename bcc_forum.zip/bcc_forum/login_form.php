 
  <form role="form" action="login.php" method="post"  >
  <table border="0" class="pull-right"><tr><td>
  
 
    <input type="text" class="form-control" id="" name="email" placeholder="Username" required>
   
 </td>
  <td>&nbsp;</td>
   <td>
  
 
    <input type="password" class="form-control" id="" name="password" placeholder="Password" required>
  
   </td> 
  <td>&nbsp;</td>
   <td>
    
 
   <button type="submit" class="btn btn-info"><i class="fa fa-sign-in"></i> Login</button>
    
   </td>
   </tr>
   </table>
</form>
  
  