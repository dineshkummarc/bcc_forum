
<?php include('header.php'); ?>

  <body id="home">
  <br />
  <?php  include('navbar_index.php');  ?>
   
  <div class="container-fluid">
  
 
  
  
<div class="row">
   
  <div class="col-md-12">

		<!-- Modal -->
		<div   id="privacy" tabindex="-1" >
		<div class="modal-dialog">
			<div class="modal-content">
			<div class="modal-header">
				<a href="index.php" type="button" class="close"  >&times;</a>
				<h4 class="modal-title" id="myModalLabel">Privacy Policy</h4>
			</div>
			<div class="modal-body">
			<p>
At certain points in the Online Forum for IT Professional and Students
 website navigation, you may be asked to share your email address or
  other personal identifying information with us. As provided in these
   Terms and Conditions, such information will never be distributed to
    a third party and it will never be publicly visible without your express written consent.<br /><br />
Your email address will only be used to send you the forum page and/or to alert you 
to any information that you have specifically requested you be notified about
</p>
			</div>
			<div class="modal-footer">
				<a href="index.php" type="button" class="btn btn-default"  ><i class="fa fa-times"></i> Close</a>
				
			</div>
			</div>
			
		</div>
		</div>
        
  </div>
 
</div>
 
  </div>
  
 
  </body>
 








